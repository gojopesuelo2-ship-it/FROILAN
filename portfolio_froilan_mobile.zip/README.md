# WEB101 - Mobile GitHub Copy for Froilan Antonio

This is a mobile-friendly copy of a portfolio website.

## Files
- `index.html`
- `styles.css`

## How to publish on GitHub Pages
1. Create a new repository (any name you want).
2. Upload these files.
3. Go to Settings → Pages → Select `main` branch.
4. After 1 minute, your website will be live.
